import FeaturesPage from "./Features/page";

export default function Home() {
  return <FeaturesPage />;
}